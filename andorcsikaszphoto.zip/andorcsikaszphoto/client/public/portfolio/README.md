# Portfolio assets

Add your photos and videos here, then update `client/src/data/portfolio.ts`.

**Photos:** Replace `photo-1.svg` through `photo-6.svg` with your images (e.g. `photo-1.jpg`). Update the `src` in portfolio.ts to match.

**Video:** Add `video-1.mp4` and optionally `video-poster.jpg` as thumbnail. Update the `src` (and `poster` if used) in portfolio.ts.
