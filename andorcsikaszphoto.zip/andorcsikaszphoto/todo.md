# Project TODO

## Getting Started
- [ ] Configure environment variables
- [ ] Set up database connection
- [ ] Add your own pages and routes
